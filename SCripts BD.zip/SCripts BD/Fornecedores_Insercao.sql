INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (10, "GROWTH", "GROWTH@EMAIL.COM", "RUA CARIRI 101", "PIX");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (20, "MAXPRO", "MAXPRO@EMAIL.COM", "AVENIDA CENTRAL 202", "BOLETO");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (30, "NUTRIMAX", "NUTRIMAX@EMAIL.COM", "RUA DAS FLORES 303", "TRANSFERENCIA");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (40, "FLEXFOOD", "FLEXFOOD@EMAIL.COM", "TRAVESSA SANTOS 404", "PIX");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (50, "SUPRALAB", "SUPRALAB@EMAIL.COM", "RUA OLÍMPIA 505", "CARTÃO");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (60, "POWERFOOD", "POWERFOOD@EMAIL.COM", "AVENIDA VARGAS 606", "BOLETO");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (70, "VITAFOR", "VITAFOR@EMAIL.COM", "RUA CRUZEIRO 707", "TRANSFERENCIA");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (80, "HEALTHSUPPLY", "HEALTHSUPPLY@EMAIL.COM", "RUA DA PAZ 808", "PIX");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (90, "NATURALFOOD", "NATURALFOOD@EMAIL.COM", "AVENIDA SOL 909", "CARTÃO");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (100, "BIOPOWER", "BIOPOWER@EMAIL.COM", "RUA AURORA 1010", "BOLETO");

INSERT INTO FORNECEDOR (fornecedor_CNPJ, fornecedor_nome, fornecedor_contato, fornecedor_endereco, pagamento)
VALUES (110, "PROHEALTH", "PROHEALTH@EMAIL.COM", "RUA NOVA 1111", "TRANSFERENCIA");
