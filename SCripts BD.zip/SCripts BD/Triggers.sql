DELIMITER $$

CREATE TRIGGER adicionarProduto
AFTER INSERT ON item_pedido
FOR EACH ROW
BEGIN
    UPDATE produtos
    SET produto_quantidade = produto_quantidade + NEW.item_quantidade
    WHERE produto_codigo = NEW.produto_id;
END$$


CREATE TRIGGER ReduzirProduto
AFTER INSERT ON item_venda
FOR EACH ROW
BEGIN
    UPDATE produtos
    SET produto_quantidade = produto_quantidade - NEW.itemV_quantidade
    WHERE produto_codigo = NEW.produto_id;
END$$


CREATE TRIGGER verificarEstoque
BEFORE INSERT ON item_venda
FOR EACH ROW
BEGIN
    DECLARE estoque_atual INT;

    SELECT produto_quantidade INTO estoque_atual
    FROM produtos
    WHERE produto_codigo = NEW.produto_id;

    IF estoque_atual < NEW.itemV_quantidade THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Estoque insuficiente para este pedido!';
    END IF;
END$$


CREATE TRIGGER criarVendaAutomatica
AFTER INSERT ON item_venda
FOR EACH ROW
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM venda WHERE venda_id = NEW.venda_id
    ) THEN
        INSERT INTO venda (venda_data, cliente_CPF, pagamento)
        VALUES (CURDATE(), NULL, NULL);
    END IF;
END$$

DELIMITER ;