INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Leite', 50, 'Bebidas', 6.00, 10);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Bolacha', 80, 'Alimentos', 3.20, 15);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Cereal', 50, 'Café da Manhã', 12.90, 10);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Molho de Tomate', 100, 'Alimentos', 2.80, 20);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Água Mineral', 200, 'Bebidas', 1.50, 50);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Chocolate', 60, 'Doces', 4.50, 10);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Shampoo', 90, 'Higiene', 15.00, 20);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Esponja', 150, 'Limpeza', 2.00, 30);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Queijo', 40, 'Laticínios', 18.00, 10);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Presunto', 50, 'Laticínios', 15.00, 10);

INSERT INTO produtos (produto_nome, produto_quantidade, produto_categoria, produto_valor, estoque_minimo)
VALUES ('Sabão em Pó', 120, 'Limpeza', 8.00, 20);
