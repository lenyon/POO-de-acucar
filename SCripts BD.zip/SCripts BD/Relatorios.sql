CREATE VIEW relatorio_vendas AS
SELECT 
    v.venda_id,
    v.venda_data AS data_de_venda,
    p.produto_nome AS produto,
    iv.itemV_quantidade AS quantidade,
    iv.itemV_preco_unitario AS preco,
    iv.itemV_subTotal AS total,
    v.pagamento,
    c.cliente_nome AS cliente
FROM 
    venda v
JOIN 
    item_venda iv ON v.venda_id = iv.venda_id
JOIN 
    produtos p ON iv.produto_id = p.produto_codigo
JOIN 
    cliente c ON v.cliente_CPF = c.cliente_CPF;


CREATE VIEW relatorio_estoque AS
SELECT 
    produto_nome AS "Produto",
    produto_categoria AS "Categoria",
    produto_quantidade AS "Quantidade Disponível",
    produto_valor AS "Valor Unitário",
    (produto_quantidade * produto_valor) AS "Valor Total em Estoque",
    CASE
        WHEN produto_quantidade < estoque_minimo THEN 'Abaixo do estoque mínimo'
        ELSE 'Normal'
    END AS "Status"
FROM 
    produtos;
    
    

CREATE VIEW relatorio_compra AS 
SELECT 
    p.pedido_data AS "Data da Compra",
    ip.item_quantidade AS "Quantidade Adquirida",
    ip.item_preco_unitario AS "Preço de Compra (Unitário)"
FROM 
    item_pedido ip
JOIN 
    pedido p ON ip.pedido_id = p.pedido_id
ORDER BY 
    p.pedido_data DESC;
    
    select * from relatorio_compra;



CREATE VIEW relatorio_desempenho_produtos AS
SELECT 
    p.produto_nome AS "Produto",
    -- Mais Vendidos
    ROUND(SUM(iv.itemV_quantidade), 2) AS "Quantidade Vendida",
    ROUND(SUM(iv.itemV_subTotal), 2) AS "Receita Total",
    -- Margem de Lucro
    ROUND(AVG(iv.itemV_preco_unitario), 2) AS "Preço Médio de Venda",
    ROUND(p.produto_valor, 2) AS "Custo Unitário",
    ROUND(AVG(iv.itemV_preco_unitario) - p.produto_valor, 2) AS "Margem de Lucro"
FROM 
    item_venda iv
JOIN 
    produtos p ON iv.produto_id = p.produto_codigo
GROUP BY 
    p.produto_nome, p.produto_valor
ORDER BY 
    "Quantidade Vendida" DESC;



CREATE VIEW fluxo_caixa AS
SELECT 
    -- Período consolidado (mês e ano)
    DATE_FORMAT(COALESCE(v.venda_data, p.pedido_data), '%Y-%m') AS "Periodo",

    -- Total de Entradas (somatório das vendas)
    SUM(CASE WHEN v.venda_id IS NOT NULL THEN iv.itemV_subTotal ELSE 0 END) AS "Total Entradas",

    -- Total de Saídas (somatório das compras)
    SUM(CASE WHEN p.pedido_id IS NOT NULL THEN ip.item_subTotal ELSE 0 END) AS "Total Saídas",

    -- Lucro Líquido (entradas menos saídas)
    SUM(CASE WHEN v.venda_id IS NOT NULL THEN iv.itemV_subTotal ELSE 0 END) -
    SUM(CASE WHEN p.pedido_id IS NOT NULL THEN ip.item_subTotal ELSE 0 END) AS "Lucro Liquido",

    -- Detalhamento de formas de pagamento nas vendas
    GROUP_CONCAT(DISTINCT v.pagamento SEPARATOR ', ') AS "Formas de Pagamento"

FROM 
    -- Entradas de dinheiro (vendas)
    venda v
LEFT JOIN 
    item_venda iv ON v.venda_id = iv.venda_id

    -- Saídas de dinheiro (compras)
LEFT JOIN 
    pedido p ON p.pedido_id = iv.venda_id
LEFT JOIN 
    item_pedido ip ON p.pedido_id = ip.pedido_id

GROUP BY 
    DATE_FORMAT(COALESCE(v.venda_data, p.pedido_data), '%Y-%m');
    

    



    

