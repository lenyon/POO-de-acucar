CREATE DATABASE poo_de_acucar;

USE poo_de_acucar;

-- Tabela de Fornecedores
CREATE TABLE FORNECEDOR (
    fornecedor_id INT AUTO_INCREMENT PRIMARY KEY,
    fornecedor_CNPJ INT UNIQUE,
    fornecedor_nome VARCHAR(255),
    fornecedor_contato VARCHAR(255),
    fornecedor_endereco VARCHAR(255),
    pagamento VARCHAR(255)
);


-- Tabela de Produtos
CREATE TABLE produtos (
    produto_codigo INT AUTO_INCREMENT PRIMARY KEY,
    produto_nome VARCHAR(255),
    produto_quantidade INT CHECK (produto_quantidade >= 0), -- Garante que o estoque não fique negativo
    produto_categoria VARCHAR(255),
    produto_valor DECIMAL(10,2),
    estoque_minimo INT DEFAULT 10
);


-- Tabela de Clientes
CREATE TABLE cliente (
    cliente_CPF VARCHAR(255) PRIMARY KEY,
    cliente_nome VARCHAR(255),
    cliente_contato VARCHAR(255)
);


-- Tabela de Pedidos
CREATE TABLE pedido (
    pedido_id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_data DATE,
    pedido_valor FLOAT,
    fornecedor_id INT,
    FOREIGN KEY (fornecedor_id) REFERENCES fornecedor(fornecedor_id)
);



-- Tabela de Itens de Pedido
CREATE TABLE item_pedido (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT,
    item_quantidade INT,
    item_preco_unitario DECIMAL(10,2),
    item_subTotal DECIMAL(10,2) GENERATED ALWAYS AS (item_quantidade * item_preco_unitario) STORED,
    produto_id INT,
    FOREIGN KEY (produto_id) REFERENCES produtos(produto_codigo),
    FOREIGN KEY (pedido_id) REFERENCES pedido(pedido_id)
);


-- Tabela de Vendas
CREATE TABLE venda (
    venda_id INT AUTO_INCREMENT PRIMARY KEY,
    venda_data DATE,
    cliente_CPF VARCHAR(255),
    pagamento VARCHAR(255),
    FOREIGN KEY (cliente_CPF) REFERENCES cliente(cliente_CPF)
);


-- Tabela de Itens de Venda
CREATE TABLE item_venda (
    itemV_id INT AUTO_INCREMENT PRIMARY KEY,
    venda_id INT,
    itemV_quantidade INT,
    itemV_preco_unitario DECIMAL(10,2),
    itemV_subTotal DECIMAL(10,2) GENERATED ALWAYS AS (itemV_quantidade * itemV_preco_unitario) STORED,
    produto_id INT,
    FOREIGN KEY (produto_id) REFERENCES produtos(produto_codigo),
    FOREIGN KEY (venda_id) REFERENCES venda(venda_id)
);




