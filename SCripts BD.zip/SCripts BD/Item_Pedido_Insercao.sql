INSERT INTO item_pedido (pedido_id,item_quantidade, item_preco_unitario, produto_id)
VALUES (1,20, 50.00, 1);