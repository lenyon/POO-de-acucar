INSERT INTO item_venda (venda_id, itemV_quantidade, itemV_preco_unitario, produto_id)
VALUES (1, 20, 50.00, 1);