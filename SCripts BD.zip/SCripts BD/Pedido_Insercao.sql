INSERT INTO pedido (pedido_data, pedido_valor, fornecedor_id)
VALUES (CURDATE(), 100.50, 1);