INSERT INTO venda (venda_data, cliente_CPF, pagamento)
VALUES (CURDATE(), "12345678900", "PIX");
SELECT * FROM venda;