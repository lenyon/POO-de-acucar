INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("12345678900", "JOAO", "JOAO@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("11122233344", "MARIA", "maria@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("55566677788", "CARLOS", "carlos@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("99988877766", "ANA", "ana@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("33344455522", "PEDRO", "pedro@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("77788899900", "FERNANDA", "fernanda@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("22233344411", "LUCIANA", "luciana@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("66655544433", "GABRIEL", "gabriel@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("88877766655", "PATRICIA", "patricia@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("44433322211", "DANIEL", "daniel@email.com");

INSERT INTO cliente (cliente_CPF, cliente_nome, cliente_contato)
VALUES ("12312312345", "CAMILA", "camila@email.com");
